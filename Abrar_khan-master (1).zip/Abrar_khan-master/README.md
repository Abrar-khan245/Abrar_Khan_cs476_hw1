Abrar Khan CS 471 

I used the example we made in class and tried my best to add on class scopes and macros. 
In Scala, we are able to call the inner and outer reference twice as what I did. 
Watching the lectures and tutorial videos of Scala gave me a better understanding of what 
can I do differently in Homework #2.  
